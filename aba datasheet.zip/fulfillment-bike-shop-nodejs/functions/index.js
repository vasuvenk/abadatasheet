/**
 * Copyright 2017 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

const functions = require('firebase-functions');
const {google} = require('googleapis');
const {WebhookClient} = require('dialogflow-fulfillment');

// Enter your calendar ID below and service account JSON below, see https://github.com/dialogflow/bike-shop/blob/master/README.md#calendar-setup
const calendarId = 'pfm2ig430rhiu7l0vrcqpj4qfs@group.calendar.google.com'; // looks like "6ujc6j6rgfk02cp02vg6h38cs0@group.calendar.google.com"
const spreadSheetId = '1v-fhnJXA5hCDVxsXh8ESwSUyJy_5JsTJarm8T3K5dvc';
const serviceAccount = {
  "type": "service_account",
  "project_id": "inputdatasheet-de16e",
  "private_key_id": "",
  "private_key": "-----BEGIN PRIVATE KEY-----\nsomekey-----END PRIVATE KEY-----\n",
  "client_email": "bike-shop-calendar@<projectid>.iam.gserviceaccount.com",
  "client_id": "105535098041731732848",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "<url>"
}; // Starts with {"type": "service_account",...

// Set up Google Calendar Service account credentials
const serviceAccountAuth = new google.auth.JWT(
	serviceAccount.client_email,
	null,
	serviceAccount.private_key,
	['https://www.googleapis.com/auth/calendar', 'https://www.googleapis.com/auth/spreadsheets'],
	null
);

const calendar = google.calendar('v3');
const sheets = google.sheets('v4');
process.env.DEBUG = 'dialogflow:*'; // enables lib debugging statements

const timeZone = 'America/Los_Angeles';
const timeZoneOffset = '-07:00';

exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });

  function hours (agent) {
    if (currentlyOpen()) {
      agent.add(`We're open now! We close at 5pm today.`);
    } else {
      agent.add(`We're currently closed, but we open every weekday at 9am!`);
    }
  }

  function makeAppointment (agent) {
    // Calculate appointment start and end datetimes (end = +1hr from start)
    const dateTimeStart = new Date(Date.parse(agent.parameters.date.split('T')[0] + 'T' + agent.parameters.time.split('T')[1].split('-')[0] + timeZoneOffset));
    const dateTimeEnd = new Date(new Date(dateTimeStart).setHours(dateTimeStart.getHours() + 1));
    const appointmentTimeString = dateTimeStart.toLocaleString(
      'en-US',
      { month: 'long', day: 'numeric', hour: 'numeric', timeZone: timeZone }
    );

    // Check the availibility of the time, and make an appointment if there is time on the calendar
    return createCalendarEvent(dateTimeStart, dateTimeEnd).then(() => {
      agent.add(`Ok, let me see if we can fit you in. ${appointmentTimeString} is fine!. Do you need a repair or just a tune-up?`);
    }).catch(() => {
      agent.add(`I'm sorry, there are no slots available for ${appointmentTimeString}.`);
    });
  }

  function setupCustomSheet (agent) {
    // TODO(vasu): Also verify that the device is text capable. Set up cannot
    // be performed on a non-texting capable device.
    let conv = agent.conv();
    if (conv == null) {
      agent.add(`This app is not supported outside of Google Assistant. Please install Google assistant to proceed.`);
    } else {
      if (conv.user == null) {
        agent.add(`Unable to access your data. Have you logged in?`);
        return;
      }
      // TODO(vasu18): Get the URL from user input.
      // conv.user.storage.behaviorparams.spreadsheetId = spreadSheetId; 
      if (conv.user.storage.behaviorparams == null || conv.user.storage.behaviorparams.spreadsheetId == null) {
        agent.add(`Please share your spreadsheet with our user and paste the spreadsheet URL here.`);
        return;
      }
      // Read the sheets and check it works.
      
      agent.add(`Verified that we are able to read your sheet`);
    }
  }

  function recordData (agent) {
    const actionTime = agent.parameters.date;
    const loc = agent.parameters.loc;

    return addInputData(agent.parameters.precedent, agent.parameters.subsequent, agent.parameters.date, agent.parameters.eventtype, agent.parameters.loc).then(() => {
    agent.add(`Ok, I have recorded your action on ${actionTime} at ${loc}`);
    }).catch(() => {
    agent.add(`I'm sorry, I couldn't add your action.`);
    });
  }

  let intentMap = new Map();
  intentMap.set('Record Data', recordData);
  intentMap.set('Setup custom spreadsheet', setupCustomSheet);
  agent.handleRequest(intentMap);
});

function addInputData (precedent, subsequent, datetime, type, loc) {  
  return new Promise((resolve, reject) => {
    sheets.spreadsheets.values.append({
      spreadsheetId: spreadSheetId,

      // The A1 notation of a range to search for a logical table of data.
      // Values will be appended after the last row of the table.
      range: 'Murari',

      // How the input data should be interpreted.
      valueInputOption: 'RAW',

      // How the input data should be inserted.
      insertDataOption: 'INSERT_ROWS',  // TODO: Update placeholder value.

      resource: {
        "values": [
          [datetime, precedent, subsequent, type, loc]
        ]
      },
      auth: serviceAccountAuth,
    }, (err, sheetsResponse) => {
      // Check if there is a event already on the Bike Shop Calendar
      if (err) {
        reject(err || new Error('Requested time conflicts with another appointment'));
      } else {
        resolve(sheetsResponse)
      }
    });
  });
}
